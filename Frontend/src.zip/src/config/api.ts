import { API_BASE_URL } from '@/url';

// const API_BASE_URL = process.env.NODE_ENV === 'production' 
//   ? '/api'  // Will be proxied by nginx to backend
//   : `${API_BASE_URL}`;

export const apiConfig = {
  baseURL: API_BASE_URL,
  timeout: 10000,
};

export default apiConfig;
